

import React from "react";
import Myapp from "./Components/Myapp";

 

const App = () => {
  
  return (
   <> 
    <Myapp/>
  
    
   </>
  );
}

export default App;
