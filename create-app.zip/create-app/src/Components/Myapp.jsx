

import React, { useState } from 'react';
import "./Myapp.css";

const Myapp = () => {
  const [currentCategory, setCurrentCategory] = useState('personal');
  const [categories, setCategories] = useState(['personal', 'work']);
  const [selectedNotes, setSelectedNotes] = useState({ category: '', note: '' });
  const [notes, setNotes] = useState({
    'personal': ['Buy Milk', 'Call Family'],
    'work': ['Prepare work', 'Finish assignment']
  });
  const [newCategory, setNewCategory] = useState('');
  const [noteContent, setNoteContent] = useState('');

  const displayCategories = () => {
    return (
      <ul>
        {categories.map((category, index) => (
          <li key={index} onClick={() => handleCategoryClick(category)}>{category}</li>
        ))}
      </ul>
    );
  };

  const handleCategoryClick = (category) => {
    setCurrentCategory(category);
  };

  const displayNotes = () => {
    return (
      <ul>
        {notes[currentCategory]?.map((note, index) => (
          <li key={index} onClick={() => handleNoteClick(note)}>{note}</li>
        ))}
      </ul>
    );
  };

  const handleNoteClick = (note) => {
    setSelectedNotes({
      category: currentCategory,
      note: note
    });
  };

  const addNotes = () => {
    if (currentCategory && noteContent) {
      setNotes(prevNotes => ({
        ...prevNotes,
        [currentCategory]: [...(prevNotes[currentCategory] || []), noteContent]
      }));
      setNoteContent('');
    }
  };

  const addCategory = () => {
    if (newCategory && !categories.includes(newCategory)) {
      setCategories(prevCategories => [...prevCategories, newCategory]);
      setNewCategory('');
    }
  };

  const deleteNotes = () => {
    const { category, note } = selectedNotes;
    if (category && note) {
      const updatedNotes = notes[category].filter(n => n !== note);
      setNotes(prevNotes => ({
        ...prevNotes,
        [category]: updatedNotes
      }));
    }
  };

  const editNote = () => {
    const { category, note } = selectedNotes;
    if (category && note && noteContent.trim() !== '') {
      const updatedNotes = notes[category].map(n => n === note ? noteContent : n);
      setNotes(prevNotes => ({
        ...prevNotes,
        [category]: updatedNotes
      }));
      setNoteContent('');
    }
  };

  return (
    <>
      <h1>Note Taking App</h1>
      <div className="container">
        <div className="sidebar">
          <h2>Categories</h2>
          {displayCategories()}
          <input
            type="text"
            placeholder='Enter a new category'
            value={newCategory}
            onChange={(e) => setNewCategory(e.target.value)}
          />
          <button onClick={addCategory}>Add Category</button>
        </div>
        <div className="main">
          <input type="text" placeholder='Search notes..' />
          {displayNotes()}
          <textarea
  placeholder='Enter your note'
   value={noteContent}
  onChange={(e) => setNoteContent(e.target.value)}
 ></textarea>

          <button onClick={addNotes}>Add Note</button>
          <button onClick={editNote}>Save changes</button>
          <button onClick={deleteNotes}>Delete Note</button>
        </div>
      </div>
    </>
  );
};

export default Myapp;
